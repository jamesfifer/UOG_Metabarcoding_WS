#####################################
#The following tutorial is modified from:
#https://benjjneb.github.io/dada2/tutorial.html
#with edits by Carly D. Kenkel & Alizah Ali & Nicola Kriefall & Sarah Davies

# source("https://bioconductor.org/biocLite.R")
# biocLite("dada2")
# biocLite('vegan')
#####################################
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("dada2")

library(dada2); #packageVersion("dada2"); citation("dada2")
library(ShortRead); #packageVersion("ShortRead")
library(ggplot2); #packageVersion("ggplot2")
library(phyloseq); #packageVersion("phyloseq")

#Set path to unzipped, renamed fastq files
path <- "~/BOSTON/Guam_16S&ITS2_Workshop/Community_Data/Comm_Data" # CHANGE ME to the directory containing the fastq files after unzipping.
fns <- list.files(path)
#Let's make sure that all of our files are there
fns

################################
##### Trimming/Filtering #######
################################

fastqs <- fns[grepl(".fastq$", fns)]
fastqs <- sort(fastqs) # Sort ensures reads are in same order
#fnFs <- fastqs[grepl("_R1", fastqs)] # Just the forward read files- these are old 454 data but most data are paired end

# Get sample names, assuming files named as so: SAMPLENAME_XXX.fastq; OTHERWISE MODIFY
sample.names <- sapply(strsplit(fastqs, ".fastq"), `[`, 1) #the last number will select the field for renaming
sample.names
# Specify the full path to the fnFs
fnFs <- file.path(path, fastqs)
fnFs

#Check for primers 
FWD <- "GTGAATTGCAGAACTCCGTG"  ## CHANGE ME to your forward primer sequence
REV <- "CCTCCGCTTACTTATATGCTT"  ## CHANGE ME...

allOrients <- function(primer) {
  # Create all orientations of the input sequence
  require(Biostrings)
  dna <- DNAString(primer)  # The Biostrings works w/ DNAString objects rather than character vectors
  orients <- c(Forward = dna, Complement = complement(dna), Reverse = reverse(dna), 
               RevComp = reverseComplement(dna))
  return(sapply(orients, toString))  # Convert back to character vector
}
FWD.orients <- allOrients(FWD)
REV.orients <- allOrients(REV)
FWD.orients
REV.orients


primerHits <- function(primer, fn) {
  # Counts number of reads in which the primer is found
  nhits <- vcountPattern(primer, sread(readFastq(fn)), fixed = FALSE)
  return(sum(nhits > 0))
}

rbind(FWD.ForwardReads = sapply(FWD.orients, primerHits, fn = fnFs[[2]]), 
     # FWD.ReverseReads = sapply(FWD.orients, primerHits, fn = fnRs[[2]]), #You can uncomment this line if you have reversereads
      REV.ForwardReads = sapply(REV.orients, primerHits, fn = fnFs[[2]])#, 
     # REV.ReverseReads = sapply(REV.orients, primerHits, fn = fnRs.filtN[[2]])#You can uncomment this line if you have reversereads
     ) 



#########Visualize Raw data

#First, lets look at quality profile of R1 reads
plotQualityProfile(fnFs[c(1,2,3,4,5,6,7,8,9)])
plotQualityProfile(fnFs[c(10,11,12,13,14,15,16,17,18)])
plotQualityProfile(fnFs[c(19,20,21,22,23,24,25,26,27)])
plotQualityProfile(fnFs[c(28,29,30,31,32,33,34,35)])
plotQualityProfile(fnFs[c(36,37,38,39,40,41)])

#Recommend trimming where quality profile crashes - in this case, forward reads mostly fine up to 300
#For common ITS amplicon strategies with paired end reads, it is undesirable to truncate reads to a fixed length due to the large amount of length variation at that locus. That is OK, just leave out truncLen. Make sure you removed the forward and reverse primers from both the forward and reverse reads though! 

#Make directory and filenames for the filtered fastqs
filt_path <- file.path(path, "trimmed")
if(!file_test("-d", filt_path)) dir.create(filt_path)
filtFs <- file.path(filt_path, paste0(sample.names, "_F_filt.fastq.gz"))

# Filter
out <- filterAndTrim(fnFs, filtFs, truncLen= 300, #end of single end reads = approx. 300 bp
                     maxN=0, #DADA does not allow Ns
                     maxEE=1, #allow 1 expected errors, where EE = sum(10^(-Q/10)); more conservative, model converges
                     truncQ=2, 
                     trimLeft=20, #N nucleotides to remove from the start of each read: ITS2 primer = F 20bp
                     rm.phix=TRUE, #remove reads matching phiX genome
                     compress=TRUE, multithread=FALSE) # On Windows set multithread=FALSE

head(out)
tail(out)

#A word on Expected Errors vs a blanket quality threshold
#Take a simple example: a read of length two with quality scores Q3 and Q40, corresponding to error probabilities P=0.5 and P=0.0001. The base with Q3 is much more likely to have an error than the base with Q40 (0.5/0.0001 = 5,000 times more likely), so we can ignore the Q40 base to a good approximation. Consider a large sample of reads with (Q3, Q40), then approximately half of them will have an error (because of the P=0.5 from the Q2 base). We express this by saying that the expected number of errors in a read with quality scores (Q3, Q40) is 0.5.
#As this example shows, low Q scores (high error probabilities) dominate expected errors, but this information is lost by averaging if low Qs appear in a read with mostly high Q scores. This explains why expected errors is a much better indicator of read accuracy than average Q.


#NOTE: At this step it is often a good idea to make sure primers are removed now. 
#If they are not you can use the follow code to remove primers. 

# cutadapt <- "/home/jamesf/.local/bin/cutadapt" # CHANGE ME TO WHEREVER YOU HAVE INSTALLED CUTADAPT
# system2(cutadapt, args = "--version")
# 
# path.cut <- file.path(path, "cutadapt")
# if(!dir.exists(path.cut)) dir.create(path.cut)
# fnFs.cut <- file.path(path.cut, basename(fnFs))
# fnRs.cut <- file.path(path.cut, basename(fnRs))
# 
# FWD.RC <- dada2:::rc(FWD)
# REV.RC <- dada2:::rc(REV)
# # Trim FWD and the reverse-complement of REV off of R1 (forward reads)
# R1.flags <- paste("-g", FWD, "-a", REV.RC) 
# # Trim REV and the reverse-complement of FWD off of R2 (reverse reads)
# R2.flags <- paste("-G", REV, "-A", FWD.RC) 
# # Run Cutadapt
# #before running, need to gunzip fastqs and then rename so it ends with fastq
# #in shell
# #gunzip -S .fastq *.fastq
# #for file in *_ITS; do     mv "$file" "${file%}.fastq"; done
# 
# for(i in seq_along(fnFs)) {
#   system2(cutadapt, args = c(R1.flags, R2.flags, "-n", 2, # -n 2 required to remove FWD and REV from reads
#                              "-o", fnFs.cut[i], "-p", fnRs.cut[i], # output files
#                              fnFs.filtN[i], fnRs.filtN[i])) # input files
# }
# 
# rbind(FWD.ForwardReads = sapply(FWD.orients, primerHits, fn = fnFs.cut[[1]]), 
#       FWD.ReverseReads = sapply(FWD.orients, primerHits, fn = fnRs.cut[[1]]), 
#       REV.ForwardReads = sapply(REV.orients, primerHits, fn = fnFs.cut[[1]]), 
#       REV.ReverseReads = sapply(REV.orients, primerHits, fn = fnRs.cut[[1]]))


################################
##### Learn Error Rates #######
################################
#DADA2 learns its error model from the data itself by alternating estimation of the error rates and the composition of the sample until they converge on a jointly consistent solution (this is similar to the E-M algorithm)
#As in many optimization problems, the algorithm must begin with an initial guess, for which the maximum possible error rates in this data are used (the error rates if only the most abundant sequence is correct and all the rest are errors).

setDadaOpt(MAX_CONSIST=30) #increase number of cycles to allow convergence
errF <- learnErrors(filtFs, multithread=TRUE)
#Maximum cycles was set to 30, but Convergence was found after 4 rounds

#sanity check: visualize estimated error rates
#error rates should decline with increasing qual score
#red line is based on definition of quality score alone
#black line is estimated error rate after convergence
#dots are observed error rate for each quality score

plotErrors(errF, nominalQ=TRUE) 

################################
##### Dereplicate reads #######
################################
#Dereplication combines all identical sequencing reads into “unique sequences” with a corresponding “abundance”: the number of reads with that unique sequence. 
#Dereplication substantially reduces computation time by eliminating redundant comparisons.
#DADA2 retains a summary of the quality information associated with each unique sequence. The consensus quality profile of a unique sequence is the average of the positional qualities from the dereplicated reads. These quality profiles inform the error model of the subsequent denoising step, significantly increasing DADA2’s accuracy.
derepFs <- derepFastq(filtFs, verbose=TRUE)
# Name the derep-class objects by the sample names
names(derepFs) <- sample.names

################################
##### Infer Sequence Variants #######
################################

#Must change some of the DADA options b/c original program optomized for ribosomal data, not ITS - from github, "We currently recommend BAND_SIZE=32 for ITS data." leave as default for 16S/18S
#Band size is the limit for number of gaps that one sequence has relative to another sequence. If it goes above this limit
#dada2 will not try to align these two sequences. Important to increase this if you have lots of expected indels (creates lots of gaps)
#ITS2 regions are indel rich compared to 16s, hence the importance of changing it from default for ITS2 analysis. 
setDadaOpt(BAND_SIZE=32)
#this is the line where we would add pool=TRUE or pool=pseudo (if we were dealing with a HUGE dataset)
#For now we will just do the default behavior because it takes less time
dadaFs <- dada(derepFs, err=errF, multithread=TRUE)


#now, look at the dada class objects by sample
#will tell how many 'real' variants in unique input seqs
#By default, the dada function processes each sample independently, but pooled processing is available with pool=TRUE and that may give better results for low sampling depths at the cost of increased computation time. See our discussion about pooling samples for sample inference. 
dadaFs[[1]]
dadaFs[[25]]

#If you had done paired end sequencing you would merge paired reads using 
#mergePairs

#construct sequence table
seqtab <- makeSequenceTable(dadaFs)
head(seqtab)

################################
##### Remove chimeras #######
################################
#The core dada method removes substitution and indel errors, but chimeras remain. 
#Fortunately, the accuracy of the sequences after denoising makes identifying chimeras easier 
#than it is when dealing with fuzzy OTUs: all sequences which can be exactly reconstructed as 
#a bimera (two-parent chimera) from more abundant sequences.

seqtab.nochim <- removeBimeraDenovo(seqtab, method="consensus", multithread=TRUE, verbose=TRUE)
dim(seqtab.nochim)
# Identified 1 bimeras out of 117 input sequences.

sum(seqtab.nochim)/sum(seqtab)
#The fraction of chimeras varies based on factors including experimental procedures and sample complexity, 
#Most of your reads should remain after chimera removal (it is not uncommon for a majority of sequence variants to be removed though)
#For our sample, this ratio was 0.9998201, there was only 1 bimera

write.csv(seqtab,file="Alizah_seqtab.csv")
write.csv(seqtab.nochim,file="Alizah_nochim.csv")
################################
##### Track Read Stats #######
################################

getN <- function(x) sum(getUniques(x))
track <- cbind(out, sapply(dadaFs, getN), sapply(dadaFs, getN), rowSums(seqtab), rowSums(seqtab.nochim))
colnames(track) <- c("input", "filtered", "denoised", "merged", "tabled", "nonchim")
rownames(track) <- sample.names
head(track)
tail(track)

write.csv(track,file="ReadFilterStats_AllData_final.csv",row.names=TRUE,quote=FALSE)


################################
##### Assign Taxonomy #######
################################

#It is common at this point, especially in 16S/18S/ITS amplicon sequencing, to classify sequence variants taxonomically. 
#DADA2 provides a native implementation of the RDP's naive Bayesian classifier. The assignTaxonomy function takes a set of sequences and a training set of taxonomically classified sequences, and outputs the taxonomic assignments with at least minBoot bootstrap confidence.
#Here, I have supplied a modified version of the GeoSymbio ITS2 database listing more taxonomic info as phyloseq requires (Franklin et al. 2012)
#For example: GeoSymbio data (taken from "all clades" at https://sites.google.com/site/geosymbio/downloads):
#>A1.1
#modified version for phyloseq looks like this instead:
#>Symbiodinium; Clade A; A1.1

taxa <- assignTaxonomy(seqtab.nochim, "../GeoSymbio_ITS2_LocalDatabase_verForPhyloseq.fasta", minBoot=5,multithread=TRUE,tryRC=TRUE,outputBootstraps=FALSE)
#minboot should be higher
#Obtain a csv file for the taxonomy so that it's easier to map the sequences for the heatmap.
write.csv(taxa, file="taxa.csv",row.name=TRUE,quote=FALSE)
unname(head(taxa, 30))
unname(taxa)

#Now, save outputs so can come back to the analysis stage at a later point if desired
saveRDS(seqtab.nochim, file="final_seqtab_nochim.rds")
saveRDS(taxa, file="final_taxa_blastCorrected.rds")

#If you need to read in previously saved datafiles
seqtab.nochim <- readRDS("final_seqtab_nochim.rds")
taxa <- readRDS("final_taxa_blastCorrected.rds")
head(taxa)

################################
#### Additional filtering, removing negative control and other sequences from unwanted DNA ####
################################

###We will be skipping these steps for the workshop###

#### Additional Filtering step 1 Removing negative Control ####
#First we need to create a fasta file from our ASV sequences

# asv_seqs <- colnames(seqtab.nochim)
# asv_headers <- vector(dim(seqtab.nochim)[2], mode="character")
# for (i in 1:dim(seqtab.nochim)[2]) {
#   asv_headers[i] <- paste(">ASV", i, sep="_")
# }
# 
# # making and writing out a fasta of our final ASV seqs:
# asv_fasta <- c(rbind(asv_headers, asv_seqs))
# write(asv_fasta, "ASVs.fa")
# 
# # count table:
# asv_tab <- t(seqtab.nochim)
# row.names(asv_tab) <- sub(">", "", asv_headers)
# write.table(asv_tab, "ASVs_counts.tsv", sep="\t", quote=F, col.names=NA)
# 
# # tax table:
# asv_tax <- taxa
# row.names(asv_tax) <- sub(">", "", asv_headers)
# write.table(asv_tax, "ASVs_taxonomy.tsv", sep="\t", quote=F, col.names=NA)
# 
# #Install the package decontaim
# BiocManager::install("decontam")
# library(decontam)
# 
# colnames(asv_tab) # our blanks are the 4th sample in this example
# vector_for_decontam <- c(rep(FALSE, 3), rep(TRUE, 1), rep(FALSE, 92))
# vector_for_decontam
# 
# contam_df <- isContaminant(t(asv_tab), neg=vector_for_decontam)
# 
# table(contam_df$contaminant) # identified X# of ASVs as contaminants
# 
# # getting vector holding the identified contaminant IDs
# contam_asvs <- row.names(contam_df[contam_df$contaminant == TRUE, ])
# contam_asvs
# #Print the ASVs identified as contaminants 
# asv_tax[row.names(asv_tax) %in% contam_asvs, ]
# #Copy those ASVs here:
# #[1] "ASV_153"  "ASV_155"  "ASV_191"  "ASV_232"  "ASV_647"  "ASV_775"  "ASV_824"  "ASV_868" 
# #[9] "ASV_994"  "ASV_1108" "ASV_1273" "ASV_1363" "ASV_1621" "ASV_1767" "ASV_2726" "ASV_2910"
# 
# #OPTIONAL If you want to see what those sequences look like in your TERMINAL you would run the following line 
# #grep -w -A1 "^>ASV_38\|^>ASV_152\|^>ASV_154\|^>ASV_193\|^>ASV_199\|^>ASV_308\|^>ASV_321\|^>ASV_337\|^>ASV_632\|^>ASV_636\|^>ASV_810\|^>ASV_915\|^>ASV_1129\|^>ASV_1326\|^>ASV_1377\|^>ASV_1706\|^>ASV_1865\|^>ASV_2221\|^>ASV_2632\" ASVs.fa
# 
# 
# # making new fasta file
# contam_indices <- which(asv_fasta %in% paste0(">", contam_asvs))
# test_indices=which(asv_fasta %in% paste0(">", nas_asvs_names))
# dont_want <- sort(c(contam_indices, contam_indices + 1))
# asv_fasta_no_contam <- asv_fasta[- dont_want]
# 
# # making new count table
# asv_tab_no_contam <- asv_tab[!row.names(asv_tab) %in% contam_asvs, ]
# 
# # making new taxonomy table
# asv_tax_no_contam <- asv_tax[!row.names(asv_tax) %in% contam_asvs, ]
# 
# ## and now writing them out to files
# write(asv_fasta_no_contam, "ASVs-no-contam.fa")
# write.table(asv_tab_no_contam, "ASVs_counts-no-contam.tsv",
#             sep="\t", quote=F, col.names=NA)
# write.table(asv_tax_no_contam, "ASVs_taxonomy-no-contam.tsv",
#             sep="\t", quote=F, col.names=NA)
# 
# 
# count_tab <- read.table("ASVs_counts-no-contam.tsv", header=T,row.names = 1,
#                         check.names=F, sep="\t")[ , -c(4)]
# 
# tax_tab <- as.matrix(read.table("ASVs_taxonomy-no-contam.tsv", header=T,
#                                 row.names=1, check.names=F, sep="\t"))
# 

#### Additional Filtering step 2 Checking external database (NCBI) for eukaryotic contamination ####

# #in TERMINAL, identify all sequences that hit eukaryote
# #>blastn -query ASV.fa  -db /ncbi/NT/nt -outfmt 6 -num_threads $nthreads -evalue 1e-5 -max_target_seqs 10 -out outputfile.txt
# ##We want to take the NCBI acc numbers from the blast output find the taxa ID and then use taxon kit 
# ##first take NCBI accession numbers
# #>cut -f2 nt.blast.out --output-delimiter='|' |rev| cut -f2 -d '|' |rev > NCBI_acc.input
# #>results=();cat NCBI_acc.input | while read p ;do results=($(efetch -db nuccore -id "$p" -format docsum |\
# # xtract -pattern DocumentSummary -element TaxId)); echo "$p" "${results[@]}" >> NCBI_acc.output; done
# #>cut -f2 NCBI_acc.output -d " ">taxa.ID
# 
# ##get the taxonomy ID files 
# #wget ftp://ftp.ncbi.nlm.nih.gov/pub/taxonomy/taxdump.tar.Z
# ##unzip file to get .dmp files
# ##directory below is location of .dmp files
# #taxonkit lineage --data-dir "/directory/for/dmpfiles/"  ./taxa.ID > taxa.ID.output
# #cut -f1 nt.blast.out>taxa.seq.ID; paste taxa.seq.ID taxa.ID.output > taxa.ID.output.withseq
# #grep "Eukaryota" taxa.ID.output.withseq | cut -f1 | sort | uniq >euk_contam_asvs
#  
# #now create new lists without eukaryotes
# euk_contam_asvs=read.table(file="euk_contam_asvs",fill = TRUE, stringsAsFactors = FALSE)
# euk_contam_asvs=euk_contam_asvs$V1
# euk_contam_asvs
# # making new count table
# asv_tab_no_euk_contam <- asv_tab[!row.names(count_tab) %in% euk_contam_asvs, ]
# 
# # making new taxonomy table
# asv_tax_no_euk_contam <- asv_tax[!row.names(tax_tab) %in% euk_contam_asvs, ]
# 
# 
# #make new counts files
# 
# write.table(asv_tab_no_euk_contam, "ASVs_counts-no-euk-contam.tsv",
#             sep="\t", quote=F, col.names=NA)
# write.table(asv_tax_no_euk_contam, "ASVs_taxonomy-no-euk-contam.tsv",
#             sep="\t", quote=F, col.names=NA)
# 
# 
# new_count_tab <- read.table("ASVs_counts-no-euk-contam.tsv", header=T,row.names = 1,
#                             check.names=F, sep="\t")[ , -c(4)]
# 
# new_tax_tab <- as.matrix(read.table("ASVs_taxonomy-no-euk-contam.tsv", header=T,
#                                     row.names=1, check.names=F, sep="\t"))
# 
# 
# #Check dada2's taxonomy assignment, sometimes with corals for 16S sequencing there will sequences assigned to 
# #unwated host or symbiont contamination
# #Remove any chloroplast, mitochondrial data or other eukaryotic data if you are doing 16S 
# ##removing chloroplast
# library(stringr)
# 
# new_tax_tab_dat= data.frame(new_tax_tab)
# is.chloro= rownames(new_tax_tab_dat[new_tax_tab_dat$Order == "Chloroplast",])
# is.chloro=is.chloro[!str_detect(is.chloro,pattern="NA")]
# 
# is.mito= rownames(new_tax_tab_dat[new_tax_tab_dat$Family == "Mitochondria",])
# is.mito=is.mito[!str_detect(is.mito,pattern="NA")]
# is.mito.chloro=append(is.mito, is.chloro)
# 
# is.euk=rownames(new_tax_tab_dat[new_tax_tab_dat$Kingdom == "Eukaryota",])
# is.euk=is.euk[!str_detect(is.euk,pattern="NA")]
# is.mito.chloro=append(is.mito, is.chloro)
# is.mito.chloro.euk=append(is.mito.chloro, is.euk)
# 
# is.arch=rownames(new_tax_tab_dat[new_tax_tab_dat$Kingdom == "Archaea",])
# is.mito.chloro.euk.arch=append(is.mito.chloro.euk, is.arch)
# new_count_tab.no.chloro.mito.euk.arch  = new_count_tab[!row.names(new_count_tab)%in%is.mito.chloro.euk.arch,]
# 
# #make sure you have deleted the neg control from the sample_info sheet
# meta = meta[-1,]
# df[match(target, df$name),]
# meta=meta[ (colnames(new_count_tab)), ]
# 
# tax_tab_phy <- tax_table(new_tax_tab)
# 
# #hand off 2 phyloseq
# ps2 <- phyloseq(otu_table(new_count_tab.no.chloro.mito.euk.arch, taxa_are_rows=T), 
#                 sample_data(meta), 
#                 tax_table(tax_tab_phy))  
# 





################################
##### handoff 2 phyloseq #######
################################

#import dataframe holding sample information
#have your samples in the same order as the seqtab file in the rows, variables as columns
samdf<-read.csv("../variabletable.csv")
head(samdf)
head(seqtab.nochim)
head(taxa)
rownames(samdf) <- samdf$sample

# Construct phyloseq object (straightforward from dada2 outputs)
ps <- phyloseq(otu_table(seqtab.nochim, taxa_are_rows=FALSE), 
               sample_data(samdf), 
               tax_table(taxa))
ps

#replace sequences with shorter names (correspondence table output below)
ids<-taxa_names(ps)
ids <- paste0("sq",seq(1, length(colnames(seqtab.nochim))))
colnames(seqtab.nochim) <- ids

#Bar-plots
top90 <- names(sort(taxa_sums(ps), decreasing=TRUE))[1:90]
#Transform to relative abudnances
ps.top90 <- transform_sample_counts(ps, function(OTU) OTU/sum(OTU))
ps.top90 <- prune_taxa(top90, ps.top90)

plot_bar(ps.top90, x="Sample", fill="Class") 

#visusalize via counts rather than abundances:
plot_bar(ps, x = "sample", fill= "Class") #+ facet_wrap("tank")
#
#Obtain a csv file for the phyloseq data. Will give you the abundances for each sample and class. Useful for constructing the heatmap.
#Also, enables you to use ggplot, and construct more aesthetically pleasing plot.
psz <- psmelt(ps.top90)
write.csv(psz, file="Phyloseqoutputfinal.csv")
p <- ggplot(psz, aes(x=Sample, y=Abundance, fill=Class))
p + geom_bar(stat="identity", colour="black")

##FOR SYMBIODINIACEAE DATA ONLY##
#~##########################################~#
###### Apply LULU to cluster ASVs ############
#~##########################################~#

#First create a fasta file 
seqtab.nochim <- readRDS("final_seqtab_nochim.rds")
asv_seqs <- colnames(seqtab.nochim)
asv_headers <- vector(dim(seqtab.nochim)[2], mode="character")
for (i in 1:dim(seqtab.nochim)[2]) {
  asv_headers[i] <- paste(">ASV", i, sep="_")
}

# making and writing out a fasta of our final ASV seqs:
asv_fasta <- c(rbind(asv_headers, asv_seqs))
write(asv_fasta, "ITS_ASVs.fa")

#install.packages("remotes")
library("remotes")
#install_github("https://github.com/tobiasgf/lulu.git")
library("lulu")

#first, read in ASV table
alldat=seqtab.nochim
ASV_IDs=substring(asv_headers, 2)
colnames(alldat)=ASV_IDs
head(alldat)

##Create a match list in your terminal
#> 
#And match list
matchList<-read.table("match_list.txt")
head(matchList)

#Reformat ASV table to desired LULU format
ASVs<-data.frame(t(alldat[])) 
head(ASVs)


curated_result <- lulu(ASVs, matchList,minimum_match=97)
summary(curated_result)
nrow(curated_result$curated_table)
#retains 68 OTUs at 97% similarity;
#% similarity threshold is super variable, some people publish with 85% similarity
#There are no clear guidelines in the symbiodiniaceae community on what threshold to choose


NEWDAT=data.frame(curated_result$curated_table)

row.names(taxa)=ASV_IDs

ps <- phyloseq(otu_table(NEWDAT, taxa_are_rows=T), 
               sample_data(samdf), 
               tax_table(taxa))

#updating seqtab.nochim post lulu removal
seqtab.nochim=data.frame(t(otu_table(ps)))

##############
####Rarefy####
##############
library(vegan)
rarecurve(t(otu_table(ps)), step=50, cex=0.005)
#rarefy by minimum sample, this is another highly variable cutoff, some people do a cutoff by a particular sample size
#e.g. 1000 reads
seqtab.nochim.rare <- data.frame(rrarefy(seqtab.nochim,sample=min(sample_sums(ps))))
#check rarecurve post rarefying 
rarecurve(seqtab.nochim.rare,step=50,cex=0.005)

###############################################################
####Trimming low abundance ASVs and purging outlier samples####
###############################################################

install.packages("MCMC.OTU")
library(MCMC.OTU)
library(tibble)
#we trim on a rarefied dataset and a non-rarefied dataset because it is considered best practice
#to do downstream analyses
#using BOTH rarefied and unrarefied data to see how much the story changes. 

#FIRST we create a trimmed dataset from a non-rarefied dataset
seqtab.4mcmc=add_column(seqtab.nochim, sample = row.names(seqtab.nochim), .after = 0)
#for columns parameter select only columns that correspond to ASVs
#otu.cut = cutoff for a fraction of total counts the OTU has to represent. This would depend on the methodology and nature of OTUs; for coral symbionts (Symbiodinium sp) the reasonable cutoff is 0.001 (Quigley et al, PLoS ONE 2014)
seqtab.trim=purgeOutliers(seqtab.4mcmc,count.columns=2:69,sampleZcut=-2.5,otu.cut=0.001,zero.cut=0.02)
#Output:
#[1] "samples with counts below z-score -2.5 :"
#character(0)
#[1] "zscores:"
#named numeric(0)
#[1] "OTUs passing frequency cutoff  1e-04 : 60"
#[1] "OTUs with counts in 0.02 of samples:"

#TRUE 
#60 

#^The above states that no samples are considered outliers, if there were any outliers we would need to remove them
#from the rarefied dataset as well and also from the list of samples using the below code
#row.names.remove <- c("B5","F9")
#samdf.trim <- samdf[!(row.names(samdf) %in% row.names.remove), ]

#SECOND we create a trimmed dataset from a rarefied dataset
seqtab.rare.4mcmc=add_column(seqtab.nochim.rare, sample = row.names(seqtab.nochim.rare), .after = 0)
#for columns parameter select only columns that correspond to ASVs
seqtab.rare.trim=purgeOutliers(seqtab.rare.4mcmc,count.columns=2:69,sampleZcut=-2.5,otu.cut=0.0001,zero.cut=0.02)

#Lets remake everything into phyloseq objects
#Rarefied only (no trim)
ps.rare <- phyloseq(otu_table(seqtab.nochim.rare, taxa_are_rows=F), 
               sample_data(samdf), 
               tax_table(taxa))
#Rarefied AND trimmed
ps.rare.trim <- phyloseq(otu_table(data.matrix(seqtab.rare.trim), taxa_are_rows=F), 
                    sample_data(samdf), 
                    tax_table(taxa))
#NOT rarefied, trimmed only
ps.trim <- phyloseq(otu_table(data.matrix(seqtab.trim), taxa_are_rows=F), 
                         sample_data(samdf), 
                         tax_table(taxa))
#########################
####Alpha Diversity####
#######################

#Visualize alpha-diversity - ***Should be done on raw, untrimmed dataset***
#total species diversity in a landscape (gamma diversity) is determined by two different things, the mean species diversity in sites or habitats at a more local scale (alpha diversity) and the differentiation among those habitats (beta diversity)
#Shannon:Shannon entropy quantifies the uncertainty (entropy or degree of surprise) associated with correctly predicting which letter will be the next in a diverse string. Based on the weighted geometric mean of the proportional abundances of the types, and equals the logarithm of true diversity. When all types in the dataset of interest are equally common, the Shannon index hence takes the value ln(actual # of types). The more unequal the abundances of the types, the smaller the corresponding Shannon entropy. If practically all abundance is concentrated to one type, and the other types are very rare (even if there are many of them), Shannon entropy approaches zero. When there is only one type in the dataset, Shannon entropy exactly equals zero (there is no uncertainty in predicting the type of the next randomly chosen entity).
#Simpson:equals the probability that two entities taken at random from the dataset of interest represent the same type. equal to the weighted arithmetic mean of the proportional abundances pi of the types of interest, with the proportional abundances themselves being used as the weights. Since mean proportional abundance of the types increases with decreasing number of types and increasing abundance of the most abundant type, ?? obtains small values in datasets of high diversity and large values in datasets of low diversity. This is counterintuitive behavior for a diversity index, so often such transformations of ?? that increase with increasing diversity have been used instead. The most popular of such indices have been the inverse Simpson index (1/??) and the Gini-Simpson index (1 ??? ??).
plot_richness(ps.rare, x="tank", measures=c("Shannon", "Simpson","Observed"), color="type") + theme_bw()


######################
####Beta Diversity####
######################

#transform to relative abundance, you will need to do some transformation if not using rarefied data.
ps.trim.rel <- transform_sample_counts(ps.trim, function(x) x / sum(x))
ord <- ordinate(ps.trim.rel, "PCoA", "bray")
plot_ordination(ps.trim.rel, ord,color="tank", shape="type")+
  stat_ellipse()+
  theme_cowplot()+
ggtitle("Trimmed NOT rarefied")


ggplot <- plot_ordination(ps.rare.trim, ordinate(ps.rare.trim, "PCoA"), color="tank", shape="type")+ 
  geom_point(size=2)+
  stat_ellipse(level=0.8,aes(lty=tank),geom="polygon",alpha=0.1)+
  
  theme_cowplot()+
 
  ggtitle("Trimmed AND rarefied")
 
ggplot

#Test for significance 
library(vegan)
#help on adonis here:
#https://thebiobucket.blogspot.com/2011/04/assumptions-for-permanova-with-adonis.html#more

#all
adonis(seqtab.all.trim[-c(1)] ~ tank, data=samdf, permutations = 1000, method="bray")






